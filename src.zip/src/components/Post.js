import React from "react";
import { Text, View, StyleSheet, TouchableOpacity } from "react-native";
import { Image, Avatar } from "react-native-elements";

const Post = ({ navigation }) => {};

const styles = StyleSheet.create({});

export default Post;
