import axios from "axios";

export default axios.create({
  baseURL: "http://5c40-102-89-3-39.ngrok.io",
});
